"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function WeatherDisplay({ latitude, longitude, locationName }) {
  const [weatherData, setWeatherData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchWeatherData = async () => {
      try {
        const response = await fetch(`/api/weather?latitude=${latitude}&longitude=${longitude}`)

        if (!response.ok) {
          throw new Error("Failed to fetch weather data")
        }

        const data = await response.json()
        setWeatherData(data)
      } catch (err) {
        setError(
          `Could not load weather data: ${err instanceof Error ? err.message : "Unknown error"}. Please try again.`,
        )
        console.error("Weather display error:", err)
      } finally {
        setIsLoading(false)
      }
    }

    fetchWeatherData()
  }, [latitude, longitude])

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>
            <Skeleton className="h-8 w-3/4" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error || !weatherData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Weather Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <p className="text-red-500">{error || "No weather data available"}</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Current Weather in {locationName}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="flex-grow">
            <div className="text-4xl font-bold mb-2">
              {weatherData.temperature}°{weatherData.temperatureUnit}
            </div>
            <div className="text-xl mb-2">{weatherData.shortForecast}</div>
            <div className="text-sm text-muted-foreground">
              Wind: {weatherData.windSpeed} {weatherData.windDirection}
            </div>
            <div className="mt-4 text-sm">{weatherData.detailedForecast}</div>
          </div>
        </div>

        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4">5-Day Forecast</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
            {weatherData.forecast.map((day, index) => (
              <div key={index} className="p-3 border rounded-lg text-center flex flex-col items-center">
                <div className="font-medium mb-2">{day.name}</div>
                <div className="text-lg font-semibold">
                  {day.temperature}°{day.temperatureUnit}
                </div>
                <div className="text-xs text-muted-foreground mt-1">{day.shortForecast}</div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
