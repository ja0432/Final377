"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function OutfitRecommendation({ temperature, condition }) {
  const [recommendation, setRecommendation] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchRecommendation = async () => {
      try {
        const response = await fetch(`/api/outfit-recommendations?temperature=${temperature}&condition=${condition}`)

        if (!response.ok) {
          throw new Error("Failed to fetch outfit recommendations")
        }

        const data = await response.json()
        setRecommendation(data)
      } catch (err) {
        setError("Could not load outfit recommendations. Please try again.")
        console.error(err)
      } finally {
        setIsLoading(false)
      }
    }

    fetchRecommendation()
  }, [temperature, condition])

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>
            <Skeleton className="h-8 w-3/4" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-24 w-full" />
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error || !recommendation) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Outfit Recommendation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <p className="text-red-500">{error || "No recommendations available"}</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recommended Outfit</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="flex-shrink-0">
            {recommendation.image_url ? (
              <img
                src={recommendation.image_url || "/placeholder.svg"}
                alt="Outfit recommendation"
                className="w-32 h-32 object-contain"
              />
            ) : (
              <div className="w-32 h-32 bg-muted flex items-center justify-center rounded-md">
                <span className="text-muted-foreground">No image</span>
              </div>
            )}
          </div>
          <div className="flex-grow">
            <p className="text-lg">{recommendation.outfit_recommendation}</p>
            <p className="text-sm text-muted-foreground mt-2">
              Recommended for temperatures between {recommendation.min_temp}°F and {recommendation.max_temp}°F in{" "}
              {recommendation.condition} conditions.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
