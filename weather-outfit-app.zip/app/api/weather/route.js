import { NextResponse } from "next/server"

export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const latitude = searchParams.get("latitude")
  const longitude = searchParams.get("longitude")

  if (!latitude || !longitude) {
    return NextResponse.json({ error: "Latitude and longitude parameters are required" }, { status: 400 })
  }

  try {
    // Format coordinates properly
    const lat = Number.parseFloat(latitude).toFixed(4)
    const lon = Number.parseFloat(longitude).toFixed(4)

    // First, get the forecast URL from the points endpoint
    const pointsResponse = await fetch(`https://api.weather.gov/points/${lat},${lon}`, {
      headers: {
        "User-Agent": "WeatherFit/1.0",
        Accept: "application/geo+json",
      },
      redirect: "follow", // Follow redirects automatically
    })

    if (!pointsResponse.ok) {
      throw new Error(`Weather API error: ${pointsResponse.status}`)
    }

    const pointsData = await pointsResponse.json()
    const forecastUrl = pointsData.properties.forecast

    // Then, get the actual forecast
    const forecastResponse = await fetch(forecastUrl, {
      headers: {
        "User-Agent": "WeatherFit/1.0",
        Accept: "application/geo+json",
      },
      redirect: "follow",
    })

    if (!forecastResponse.ok) {
      throw new Error(`Forecast API error: ${forecastResponse.status}`)
    }

    const forecastData = await forecastResponse.json()

    // Get the current period (first period in the forecast)
    const currentPeriod = forecastData.properties.periods[0]

    // Simplify the weather data we return
    const weatherData = {
      temperature: currentPeriod.temperature,
      temperatureUnit: currentPeriod.temperatureUnit,
      shortForecast: currentPeriod.shortForecast,
      detailedForecast: currentPeriod.detailedForecast,
      icon: currentPeriod.icon,
      // Get the next 5 periods for the forecast
      forecast: forecastData.properties.periods.slice(0, 5).map((period) => ({
        name: period.name,
        temperature: period.temperature,
        shortForecast: period.shortForecast,
        icon: period.icon,
      })),
    }

    return NextResponse.json(weatherData)
  } catch (error) {
    console.error("Weather API error:", error)
    return NextResponse.json({ error: "Failed to fetch weather data" }, { status: 500 })
  }
}
