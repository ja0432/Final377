import { NextResponse } from "next/server"
import { getServerClient } from "@/lib/supabase"

export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const temperature = searchParams.get("temperature")
  const condition = searchParams.get("condition")

  if (!temperature || !condition) {
    return NextResponse.json({ error: "Temperature and condition parameters are required" }, { status: 400 })
  }

  try {
    const tempValue = Number.parseInt(temperature)
    let weatherCondition = "clear"

    // Map the weather condition to our database values (simplify to just rain or clear)
    if (
      condition.toLowerCase().includes("rain") ||
      condition.toLowerCase().includes("shower") ||
      condition.toLowerCase().includes("drizzle")
    ) {
      weatherCondition = "rain"
    }

    const supabase = getServerClient()

    // Log the query parameters for debugging
    console.log(`Searching for outfit with temp: ${tempValue}, condition: ${weatherCondition}`)

    // Find outfit recommendation that matches the temperature and condition
    const { data, error } = await supabase
      .from("outfit_recommendations")
      .select("*")
      .lte("max_temp", tempValue)
      .gte("min_temp", tempValue)
      .eq("condition", weatherCondition)
      .limit(1)

    if (error) {
      console.error("Supabase error:", error)
      return NextResponse.json({ error: "Failed to fetch outfit recommendations" }, { status: 500 })
    }

    console.log("Outfit query result:", data)

    if (!data || data.length === 0) {
      console.log("No exact match found, trying fallback query")
      // If no exact match, get a fallback recommendation
      const { data: fallbackData, error: fallbackError } = await supabase
        .from("outfit_recommendations")
        .select("*")
        .eq("condition", weatherCondition)
        .order("min_temp", { ascending: tempValue < 50 })
        .limit(1)

      if (fallbackError) {
        console.error("Fallback query error:", fallbackError)
        return NextResponse.json({ error: "Failed to fetch fallback outfit recommendations" }, { status: 500 })
      }

      console.log("Fallback result:", fallbackData)

      if (!fallbackData || fallbackData.length === 0) {
        // If still no results, return a hardcoded recommendation
        console.log("No recommendations found in database, using hardcoded fallback")
        const hardcodedRecommendation = {
          id: 999,
          min_temp: tempValue - 10,
          max_temp: tempValue + 10,
          condition: weatherCondition,
          outfit_recommendation:
            tempValue > 70
              ? "Light clothing such as t-shirts and shorts. Consider sunscreen and a hat if it's sunny."
              : tempValue > 50
                ? "Medium layers like a light jacket or sweater with pants."
                : "Warm clothing including a coat, hat, and gloves.",
          image_url: null,
        }
        return NextResponse.json(hardcodedRecommendation)
      }

      return NextResponse.json(fallbackData[0])
    }

    return NextResponse.json(data[0])
  } catch (error) {
    console.error("Outfit recommendations error:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}
