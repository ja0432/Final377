"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { History } from "lucide-react"

interface SearchHistoryItem {
  id: number
  location: string
  latitude: number
  longitude: number
  searched_at: string
}

export default function SearchHistory() {
  const [history, setHistory] = useState<SearchHistoryItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const fetchSearchHistory = async () => {
      try {
        const response = await fetch("/api/search-history")

        if (response.ok) {
          const data = await response.json()
          setHistory(data)
        }
      } catch (error) {
        console.error("Failed to fetch search history:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchSearchHistory()
  }, [])

  const handleLocationClick = (latitude: number, longitude: number, location: string) => {
    router.push(`/results?latitude=${latitude}&longitude=${longitude}&location=${encodeURIComponent(location)}`)
  }

  if (isLoading) {
    return null
  }

  if (history.length === 0) {
    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <History className="h-5 w-5 mr-2" />
          Recent Searches
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {history.map((item) => (
            <Button
              key={item.id}
              variant="outline"
              size="sm"
              onClick={() => handleLocationClick(item.latitude, item.longitude, item.location)}
            >
              {item.location.split(",")[0]}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
