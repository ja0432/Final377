"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

export default function SearchForm() {
  const [location, setLocation] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)
  const router = useRouter()

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!location.trim()) {
      setError("Please enter a location")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      // Redirect to the results page with the location as a query parameter
      router.push(`/results?location=${encodeURIComponent(location)}`)
    } catch (err) {
      setError("An error occurred. Please try again.")
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-md mx-auto">
      <div className="flex w-full items-center space-x-2">
        <Input
          type="text"
          placeholder="Enter city or location..."
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="flex-1"
          disabled={isLoading}
        />
        <Button type="submit" disabled={isLoading}>
          {isLoading ? <span className="animate-spin mr-2">⟳</span> : <Search className="h-4 w-4 mr-2" />}
          Search
        </Button>
      </div>
      {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
    </form>
  )
}
