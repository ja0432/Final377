import { NextResponse } from "next/server"
import { getServerClient } from "@/lib/supabase"

export async function POST(request) {
  try {
    const { location, latitude, longitude } = await request.json()

    if (!location || !latitude || !longitude) {
      return NextResponse.json({ error: "Location, latitude, and longitude are required" }, { status: 400 })
    }

    const supabase = getServerClient()

    // Check if the table exists
    const { error: tableCheckError } = await supabase.from("search_history").select("id").limit(1)

    if (tableCheckError) {
      console.error("Table check error:", tableCheckError)
      // If the table doesn't exist, return success anyway to avoid breaking the app
      return NextResponse.json({ success: true, message: "Search history feature not available" })
    }

    const { data, error } = await supabase.from("search_history").insert([{ location, latitude, longitude }]).select()

    if (error) {
      console.error("Supabase error:", error)
      return NextResponse.json({ error: "Failed to save search history" }, { status: 500 })
    }

    return NextResponse.json({ success: true, data })
  } catch (error) {
    console.error("Search history error:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const supabase = getServerClient()

    // Check if the table exists
    const { error: tableCheckError } = await supabase.from("search_history").select("id").limit(1)

    if (tableCheckError) {
      console.error("Table check error:", tableCheckError)
      // If the table doesn't exist, return an empty array
      return NextResponse.json([])
    }

    const { data, error } = await supabase
      .from("search_history")
      .select("*")
      .order("searched_at", { ascending: false })
      .limit(5)

    if (error) {
      console.error("Supabase error:", error)
      return NextResponse.json({ error: "Failed to fetch search history" }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Search history error:", error)
    return NextResponse.json([])
  }
}
